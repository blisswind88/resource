#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
compare_tbox.py — 엑셀에서 만든 TBox와 원본 dita-workflow.ttl의 클래스·속성 집합을 대조한다.

이 세션에서는 원본 TTL을 읽지 못해 실행하지 못했다. 사용자 PC에서 실행해
'엑셀만 있음'·'TTL만 있음' 항목이 0건인지 확인한다.

사용: python3 -I compare_tbox.py tbox-from-xlsx.ttl /경로/dita-workflow.ttl
종료 코드: 차이가 없으면 0, 있으면 1
"""
import sys
from pathlib import Path
from rdflib import Graph, RDF, RDFS, OWL

WF = 'https://example.org/dita-wf#'


def q(u):
    return 'wf:' + str(u)[len(WF):] if str(u).startswith(WF) else str(u)


def sets(path):
    g = Graph(); g.parse(str(path))
    classes = {s for s in g.subjects(RDF.type, OWL.Class)} | \
              {s for s in g.subjects(RDFS.subClassOf, None)}
    props = {s for s in g.subjects(RDF.type, OWL.ObjectProperty)} | \
            {s for s in g.subjects(RDF.type, OWL.DatatypeProperty)}
    keep = lambda S: {q(x) for x in S if str(x).startswith(WF)}
    return keep(classes), keep(props), g


def report(name, a, b, la, lb):
    only_a, only_b = sorted(a - b), sorted(b - a)
    print(f'\n== {name} ==')
    print(f'  {la}: {len(a)}개 · {lb}: {len(b)}개 · 공통: {len(a & b)}개')
    for lbl, items in ((f'{la}에만 있음', only_a), (f'{lb}에만 있음', only_b)):
        if items:
            print(f'  [{lbl}] {len(items)}건')
            for i in items:
                print('    -', i)
    return not (only_a or only_b)


def main():
    xlsx_ttl, src_ttl = Path(sys.argv[1]), Path(sys.argv[2])
    ca, pa, _ = sets(xlsx_ttl)
    cb, pb, gb = sets(src_ttl)
    ok1 = report('클래스', ca, cb, '엑셀', 'TTL')
    ok2 = report('속성',   pa, pb, '엑셀', 'TTL')
    print(f'\n원본 TTL 전체 트리플: {len(gb)}개')
    print('\n판정:', '일치 — 엑셀이 온톨로지를 그대로 담고 있다'
          if ok1 and ok2 else '불일치 — 위 목록을 확인하라')
    sys.exit(0 if ok1 and ok2 else 1)


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
extract_ontology.py — v3 워크플로우 엑셀에서 온톨로지 항목을 추출한다.

입력 : DITA_매뉴얼_초안_자동화_워크플로우_v3.xlsx
출력 : ontology-core.json  (클래스·속성·개체 집합)
       classes.csv, properties.csv, individuals.csv
사용 : python3 -I extract_ontology.py <xlsx> <outdir>

주의: 엑셀은 온톨로지(dita-workflow.ttl)의 사본 표현이다. 이 스크립트는 엑셀만 읽으므로
      TTL 원본과의 일치는 별도로 대조해야 한다 (--compare 미구현, TTL 미제공).
"""
import sys, json, csv, re, hashlib
from pathlib import Path
import openpyxl

SHEET_SCHEMA = '온톨로지 스키마'
SHEET_MAP    = '온톨로지 매핑'
SHEET_WF     = '워크플로우'
SHEET_TRANS  = '전이 목록'
SHEET_SEND   = '외부 전송'
SHEET_RULES  = '검증 규칙·결과'


def rows(ws):
    """시트를 문자열 리스트의 리스트로. 빈 꼬리 칸 제거."""
    out = []
    for r in ws.iter_rows(values_only=True):
        cells = ['' if c is None else str(c).strip() for c in r]
        while cells and cells[-1] == '':
            cells.pop()
        out.append(cells)
    return out


def parse_schema(ws):
    """'클래스' / '속성' 구역을 머리글 줄로 찾아 나눈다."""
    data = rows(ws)
    classes, properties, vocab = [], [], []
    section = None
    for cells in data:
        if not cells:
            continue
        head = cells[0]
        if head == '재사용 어휘':
            section = 'vocab';  continue
        if head == '클래스':
            section = 'class';  continue
        if head == '속성':
            section = 'prop';   continue
        # 머리글 줄 건너뛰기
        if head in ('클래스 ID', '속성 ID', '접두사'):
            continue
        if section == 'vocab' and len(cells) >= 2:
            vocab.append({
                'prefix': cells[0], 'namespace': cells[1],
                'source': cells[2] if len(cells) > 2 else '',
                'used': cells[3] if len(cells) > 3 else '',
            })
        elif section == 'class' and head.startswith('wf:'):
            sup = cells[2] if len(cells) > 2 else ''
            classes.append({
                'id': head,
                'label': cells[1] if len(cells) > 1 else '',
                'subClassOf': '' if sup in ('—', '-', '') else sup,
                'comment': cells[3] if len(cells) > 3 else '',
            })
        elif section == 'prop' and head.startswith('wf:'):
            def g(i):
                v = cells[i] if len(cells) > i else ''
                return '' if v in ('—', '-') else v
            properties.append({
                'id': head,
                'label': g(1),
                'kind': g(2),               # 데이터 속성 / 객체 속성
                'domain': g(3),
                'range': g(4),
                'subPropertyOf': g(5),
                'comment': g(6),
            })
    return vocab, classes, properties


def parse_steps(ws):
    data = rows(ws)
    hdr_i = next(i for i, c in enumerate(data) if c and c[0] == '순서')
    hdr = data[hdr_i]
    col = {name: i for i, name in enumerate(hdr)}
    steps = []
    for cells in data[hdr_i + 1:]:
        if not cells or not re.fullmatch(r'\d+', cells[0]):
            continue
        def g(name):
            i = col.get(name)
            return cells[i] if i is not None and len(cells) > i else ''
        label = g('사람 개입') or g('LLM 에이전트') or g('스크립트')
        steps.append({
            'id': g('온톨로지 ID'),
            'stepNumber': int(cells[0]),
            'label': label,
            'performedByText': g('구분'),
            'task': g('작업 내용'),
            'inputText': g('입력 (필요 자료)'),
            'outputText': g('출력물'),
            'resourceText': g('필요 에이전트/템플릿'),
            'nextText': g('다음 단계·분기'),
            'sendText': g('외부 전송 (LLM API)'),
            'templates': g('필요 템플릿 (ID · 권장 포맷)'),
        })
    return steps


AGENT_OF = {
    '사람': ['wf:Human'], 'LLM': ['wf:LLMAgent'], '스크립트': ['wf:Script'],
    'LLM+스크립트': ['wf:LLMAgent', 'wf:Script'],
}

# 단계 성격 분류 — '온톨로지 매핑' 시트가 "누가"와 "무엇을"을 별개 축으로 둔다고 적었으나
# 엑셀에 단계별 성격 열이 없다. 작업 내용·단계 이름에서 규칙으로 유도한다. [기본값]
def classify(step):
    n, lab, task = step['stepNumber'], step['label'], step['task']
    if '승인' in lab and '최종 출력물' not in lab:
        return 'wf:ApprovalStep'
    if n == 19:
        return 'wf:ApprovalStep'
    if n == 16:
        return 'wf:DecisionStep'
    if n == 1:
        return 'wf:DefinitionStep'
    if '제안' in lab:
        return 'wf:ProposalStep'
    if '검증' in lab or '검사' in lab:
        return 'wf:ValidationStep'
    if '수정' in lab and '반영' in lab:
        return 'wf:CorrectionStep'
    if '변환' in lab:
        return 'wf:PublishingStep'
    if '검토' in lab:
        return 'wf:ReviewStep'
    return 'wf:CreationStep'


def parse_transitions(ws):
    data = rows(ws)
    hdr_i = next(i for i, c in enumerate(data) if c and c[0] == '전이 ID')
    out = []
    for cells in data[hdr_i + 1:]:
        if not cells or not cells[0].startswith('wf:t'):
            continue
        def g(i):
            return cells[i] if len(cells) > i else ''
        def num(s):
            m = re.match(r'(\d+)\.', s)
            return int(m.group(1)) if m else None
        out.append({
            'id': cells[0],
            'fromStep': num(g(1)), 'fromLabel': g(1),
            'toStep': num(g(2)),   'toLabel': g(2),
            'condition': g(3),
            'isBackward': g(4) == '예',
            'countsTowardIteration': {'예': True, '아니요': False}.get(g(5)),
            'note': g(6),
        })
    return out


def parse_transmissions(ws):
    data = rows(ws)
    hdr_i = next(i for i, c in enumerate(data) if c and c[0] == '순서')
    out = []
    for cells in data[hdr_i + 1:]:
        if not cells or not re.fullmatch(r'\d+', cells[0]):
            continue
        def g(i):
            return cells[i] if len(cells) > i else ''
        out.append({
            'stepNumber': int(cells[0]), 'stepLabel': g(1), 'performedBy': g(2),
            'sends': g(3) == '예',
            'artifact': '' if g(4) == '—' else g(4),
            'condition': '' if g(5) == '—' else g(5),
        })
    return out


def parse_rules(ws):
    data = rows(ws)
    hdr_i = next(i for i, c in enumerate(data) if c and c[0] == '규칙')
    out = []
    for cells in data[hdr_i + 1:]:
        if not cells or not re.fullmatch(r'R\d+', cells[0]):
            continue
        def g(i):
            return cells[i] if len(cells) > i else ''
        out.append({'id': cells[0], 'check': g(1), 'severity': g(2),
                    'v2': g(3), 'v3': g(4)})
    return out


def main():
    xlsx, outdir = Path(sys.argv[1]), Path(sys.argv[2])
    outdir.mkdir(parents=True, exist_ok=True)
    wb = openpyxl.load_workbook(xlsx, data_only=True)

    vocab, classes, properties = parse_schema(wb[SHEET_SCHEMA])
    steps        = parse_steps(wb[SHEET_WF])
    transitions  = parse_transitions(wb[SHEET_TRANS])
    transmissions= parse_transmissions(wb[SHEET_SEND])
    rules        = parse_rules(wb[SHEET_RULES])

    for s in steps:
        s['performedBy'] = AGENT_OF.get(s['performedByText'], [])
        s['stepClass']   = classify(s)

    # 자료(wf:Artifact) 개체 — 외부 전송 시트에서 실제 이름이 확인된 것만
    artifacts = sorted({t['artifact'] for t in transmissions if t['artifact']})

    core = {
        'schema_version': '1.0',
        'source': {
            'file': xlsx.name,
            'sha256_12': hashlib.sha256(xlsx.read_bytes()).hexdigest()[:12],
            'sheets': [SHEET_SCHEMA, SHEET_WF, SHEET_TRANS, SHEET_SEND, SHEET_RULES],
            'note': 'TTL 원본(dita-workflow.ttl) 미제공 — 엑셀 표현만 반영',
        },
        'namespace': 'https://example.org/dita-wf#',
        'reused_vocabularies': vocab,
        'classes': classes,
        'properties': properties,
        'individuals': {
            'steps': steps,
            'transitions': transitions,
            'transmissions': transmissions,
            'artifacts_seen_in_transmissions': artifacts,
        },
        'shacl_rules': rules,
        'counts': {
            'classes': len(classes),
            'properties': len(properties),
            'object_properties': sum(1 for p in properties if p['kind'] == '객체 속성'),
            'data_properties':   sum(1 for p in properties if p['kind'] == '데이터 속성'),
            'steps': len(steps),
            'transitions': len(transitions),
            'transmissions_yes': sum(1 for t in transmissions if t['sends']),
            'shacl_rules': len(rules),
        },
    }

    (outdir / 'ontology-core.json').write_text(
        json.dumps(core, ensure_ascii=False, indent=2), encoding='utf-8')

    def dump(name, rows_, fields):
        with (outdir / name).open('w', newline='', encoding='utf-8-sig') as f:
            w = csv.DictWriter(f, fieldnames=fields, extrasaction='ignore')
            w.writeheader(); w.writerows(rows_)

    dump('classes.csv', classes, ['id', 'label', 'subClassOf', 'comment'])
    dump('properties.csv', properties,
         ['id', 'label', 'kind', 'domain', 'range', 'subPropertyOf', 'comment'])
    dump('individuals-steps.csv', steps,
         ['id', 'stepNumber', 'label', 'stepClass', 'performedByText', 'nextText'])

    print(json.dumps(core['counts'], ensure_ascii=False, indent=2))
    return core


if __name__ == '__main__':
    main()

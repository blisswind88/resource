#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
emit_tbox.py — ontology-core.json에서 TBox만 Turtle로 쓴다.

용도: 원본 dita-workflow.ttl과 대조해 엑셀 '온톨로지 스키마' 시트가 온톨로지와
      어긋나지 않았는지 확인한다. 개체(ABox)는 쓰지 않는다.

사용: python3 -I emit_tbox.py <ontology-core.json> <out.ttl>
대조: python3 -I compare_tbox.py <out.ttl> <dita-workflow.ttl>
"""
import sys, json
from pathlib import Path
from rdflib import Graph, Namespace, RDF, RDFS, OWL, XSD, URIRef, Literal

WF = Namespace('https://example.org/dita-wf#')
PPLAN = Namespace('http://purl.org/net/p-plan#')
PROV = Namespace('http://www.w3.org/ns/prov#')
NS = {'wf': WF, 'p-plan': PPLAN, 'prov': PROV,
      'xsd': XSD, 'rdfs': RDFS, 'owl': OWL}


def term(qname):
    """'wf:Step' / 'xsd:integer' → URIRef. 모르는 접두사는 None."""
    if not qname or ':' not in qname:
        return None
    pre, local = qname.split(':', 1)
    ns = NS.get(pre)
    return URIRef(str(ns) + local) if ns is not None else None


def main():
    src, dst = Path(sys.argv[1]), Path(sys.argv[2])
    d = json.loads(src.read_text(encoding='utf-8'))
    g = Graph()
    for p, n in NS.items():
        g.bind(p, str(n))

    skipped = []
    for c in d['classes']:
        s = term(c['id'])
        g.add((s, RDF.type, OWL.Class))
        if c['label']:
            g.add((s, RDFS.label, Literal(c['label'], lang='ko')))
        if c['comment']:
            g.add((s, RDFS.comment, Literal(c['comment'], lang='ko')))
        sup = term(c['subClassOf'])
        if sup is not None:
            g.add((s, RDFS.subClassOf, sup))
        elif c['subClassOf']:
            skipped.append(('subClassOf', c['id'], c['subClassOf']))

    for p in d['properties']:
        s = term(p['id'])
        kind = OWL.ObjectProperty if p['kind'] == '객체 속성' else OWL.DatatypeProperty
        g.add((s, RDF.type, kind))
        if p['label']:
            g.add((s, RDFS.label, Literal(p['label'], lang='ko')))
        if p['comment']:
            g.add((s, RDFS.comment, Literal(p['comment'], lang='ko')))
        for key, pred in (('domain', RDFS.domain), ('range', RDFS.range),
                          ('subPropertyOf', RDFS.subPropertyOf)):
            t = term(p[key])
            if t is not None:
                g.add((s, pred, t))
            elif p[key]:
                skipped.append((key, p['id'], p[key]))

    g.serialize(destination=str(dst), format='turtle')
    print(f'{dst.name}: 트리플 {len(g)}개 '
          f'(클래스 {len(d["classes"])} · 속성 {len(d["properties"])})')
    if skipped:
        print('접두사를 몰라 건너뛴 값:')
        for k, sid, v in skipped:
            print(f'  {sid} {k} = {v}')
    print('\n원본 대조: 이 파일은 엑셀에서 만든 TBox다. 실제 dita-workflow.ttl과')
    print('클래스·속성 집합이 같은지 확인해야 엑셀이 온톨로지와 일치한다고 말할 수 있다.')


if __name__ == '__main__':
    main()

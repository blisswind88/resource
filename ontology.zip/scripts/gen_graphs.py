#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen_graphs.py — ontology-core.json에서 시각화용 DOT와 PNG/SVG를 만든다.

출력: 01-class-hierarchy / 02-class-relationships / 03-core-concept-map (.dot/.png/.svg)
사용: python3 -I gen_graphs.py <ontology-core.json> <outdir>
"""
import sys, json, subprocess
from pathlib import Path

FONT = 'Noto Sans CJK KR'

# 코어 개념 축 — 45개 클래스를 7축으로 묶는다. [기본값: 사용자 확인 필요]
AXES = {
    'plan':   ('계획·단계',   '#1f4e79', '#dce9f5'),
    'agent':  ('수행 주체',   '#9c4a00', '#fbe4d0'),
    'data':   ('자료',        '#1b5e3f', '#d8ecdf'),
    'flow':   ('흐름 제어',   '#5b2d82', '#e8ddf2'),
    'ctrl':   ('통제·보안',   '#9b1c1c', '#fadddd'),
    'cat':    ('분류·상태',   '#0f5b63', '#d5eced'),
    'hist':   ('이력·근거',   '#4a4a4a', '#e6e6e6'),
}

AXIS_OF = {
    'wf:Workflow':'plan','wf:Step':'plan','wf:DefinitionStep':'plan','wf:ProposalStep':'plan',
    'wf:CreationStep':'plan','wf:ApprovalStep':'plan','wf:ReviewStep':'plan','wf:DecisionStep':'plan',
    'wf:ValidationStep':'plan','wf:CorrectionStep':'plan','wf:PublishingStep':'plan',
    'wf:Human':'agent','wf:LLMAgent':'agent','wf:Script':'agent',
    'wf:Artifact':'data','wf:SourceMaterial':'data','wf:ExternalStandard':'data','wf:Resource':'data',
    'wf:Template':'data','wf:TemplatePart':'data','wf:Tool':'data','wf:LLMSkill':'data',
    'wf:WorkProduct':'data','wf:DITAMap':'data','wf:DITATopicSet':'data','wf:Report':'data',
    'wf:FinalDeliverable':'data',
    'wf:Transition':'flow','wf:Condition':'flow','wf:RejectionCondition':'flow',
    'wf:IterationRule':'flow','wf:SkipRule':'flow','wf:Terminal':'flow',
    'wf:Constraint':'ctrl','wf:ScopeConstraint':'ctrl','wf:IndependenceConstraint':'ctrl',
    'wf:SecurityConstraint':'ctrl','wf:ExternalTransmission':'ctrl','wf:TransmissionCondition':'ctrl',
    'wf:TopicState':'cat','wf:ManualType':'cat','wf:Availability':'cat',
    'wf:Decision':'hist','wf:ChangeRecord':'hist','wf:OriginalStep':'hist',
}

EXTERNAL = {  # 재사용 어휘 노드
    'p-plan:Plan':'P-Plan','p-plan:Step':'P-Plan','p-plan:Variable':'P-Plan',
    'prov:Person':'PROV-O','prov:SoftwareAgent':'PROV-O','prov:Agent':'PROV-O',
}

# PROV-O 안의 계층 — 엑셀에는 없고 PROV-O 규격에 있는 연결.
# wf:performedBy의 치역이 prov:Agent라서, 이 두 줄이 있어야 수행 주체 축이 단계와 이어진다.
# 근거: W3C PROV-O Recommendation (2013-04-30) — prov:Person·prov:SoftwareAgent ⊑ prov:Agent
PROV_BRIDGE = [('prov:Agent', 'prov:Person'), ('prov:Agent', 'prov:SoftwareAgent')]

# 엑셀에 정의역 또는 치역이 비어 있는 객체 속성 — 그래프에서 점선으로 '미기재'를 드러낸다.
# 화살표가 가리키는 끝은 작업 내용·전이 목록에서 읽은 추정이며 TTL 대조가 필요하다. [기본값]
GAP_EDGES = [
    ('wf:Transition', 'wf:Step',       'wf:toStep',       '치역 미기재 (추정: 단계)'),
    ('wf:Transition', 'wf:Terminal',   'wf:toStep',       '치역 미기재 (추정: 종료 지점)'),
    ('wf:Step',       'wf:Constraint', 'wf:hasConstraint','정의역 미기재 (추정: 단계)'),
]


def esc(s):
    return s.replace('"', '\\"')


def node_id(cid):
    return '"' + esc(cid) + '"'


def cls_node(c, show_axis=True):
    """클래스 노드 선언."""
    axis = AXIS_OF.get(c['id'], 'hist')
    pen, fill = AXES[axis][1], AXES[axis][2]
    label = f"{c['label']}\\n{c['id']}"
    return (f'  {node_id(c["id"])} [label="{esc(label)}", fillcolor="{fill}", '
            f'color="{pen}", fontcolor="#111111"];')


def ext_node(eid):
    return (f'  {node_id(eid)} [label="{esc(eid)}\\n({EXTERNAL[eid]})", '
            f'shape=box, style="rounded,dashed,filled", fillcolor="#f7f7f7", '
            f'color="#999999", fontcolor="#555555", fontsize=10];')


HEADER = """digraph onto {{
  rankdir={rankdir};
  bgcolor="white";
  graph [fontname="{font}", fontsize=11, labelloc="t", label=<{title}>,
         nodesep={nodesep}, ranksep={ranksep}, splines={splines}, pad=0.4, compound=true];
  node  [fontname="{font}", fontsize=11, shape=box, style="rounded,filled",
         penwidth=1.4, margin="0.14,0.07"];
  edge  [fontname="{font}", fontsize=9, color="#777777", arrowsize=0.7];
"""


def legend(axes_used, extra_rows=()):
    rows = []
    for k in AXES:
        if k not in axes_used:
            continue
        name, pen, fill = AXES[k]
        rows.append(f'<TR><TD BGCOLOR="{fill}" WIDTH="18"></TD>'
                    f'<TD ALIGN="LEFT"><FONT POINT-SIZE="10">{name}</FONT></TD></TR>')
    for txt in extra_rows:
        rows.append(f'<TR><TD COLSPAN="2" ALIGN="LEFT"><FONT POINT-SIZE="9" COLOR="#555555">'
                    f'{txt}</FONT></TD></TR>')
    body = ''.join(rows)
    return ('  subgraph cluster_legend {\n'
            '    label=""; color="#cccccc"; style="rounded"; margin=8;\n'
            f'    LEGEND [shape=plaintext, style="", label=<<TABLE BORDER="0" '
            f'CELLBORDER="0" CELLSPACING="3">{body}</TABLE>>];\n'
            '  }\n')


def prop_edges(props, show_id=False):
    """객체 속성을 간선으로.

    같은 클래스를 정의역·치역으로 갖는 자기 참조 속성은 간선을 따로 그리면 라벨이 겹치므로
    한 노드당 자기 참조 간선 1개로 묶고 라벨을 여러 줄로 적는다.
    """
    out, selfs = [], {}
    for p in props:
        pen = AXES[AXIS_OF.get(p['domain'], 'hist')][1]
        lab = f'{p["label"]}\\n{p["id"]}' if show_id else p['label']
        if p['domain'] == p['range']:
            selfs.setdefault(p['domain'], []).append(
                f'{p["label"]} ({p["id"]})' if show_id else p['label'])
            continue
        out.append(f'  {node_id(p["domain"])} -> {node_id(p["range"])} '
                   f'[label="{esc(lab)}", color="{pen}", fontcolor="{pen}", penwidth=1.1];')
    # 자기 참조 속성(정의역 = 치역)은 간선 라벨로 그리면 노드·다른 라벨과 겹친다.
    # 쪽지 노드로 빼면 graphviz가 자리를 잡아 주므로 겹치지 않는다.
    for cid, labs in selfs.items():
        pen = AXES[AXIS_OF.get(cid, 'hist')][1]
        note = f'"__self_{cid}"'
        body = '<BR/>'.join(f'↻ {esc(l)}' for l in labs)
        out.append(f'  {note} [shape=note, style="filled", fillcolor="#ffffff", '
                   f'color="{pen}", fontcolor="{pen}", fontsize=9, margin="0.10,0.06", '
                   f'label=<{body}>];')
        out.append(f'  {node_id(cid)} -> {note} [color="{pen}", penwidth=1.0, '
                   f'arrowhead=none, style=dotted];')
    return out


def bridge_and_gap_edges():
    """PROV-O 계층 다리와 정의역·치역 미기재 간선."""
    out = []
    for sup, sub in PROV_BRIDGE:
        out.append(f'  {node_id(sup)} -> {node_id(sub)} '
                   f'[arrowhead=empty, color="#999999", style=dashed, penwidth=1.0];')
    for sub, sup in (('wf:Human', 'prov:Person'),
                     ('wf:LLMAgent', 'prov:SoftwareAgent'),
                     ('wf:Script', 'prov:SoftwareAgent')):
        out.append(f'  {node_id(sup)} -> {node_id(sub)} '
                   f'[arrowhead=empty, color="#999999", style=dashed, penwidth=1.0];')
    for src, tgt, pid, note in GAP_EDGES:
        out.append(f'  {node_id(src)} -> {node_id(tgt)} '
                   f'[label="{esc(pid)}\\n{esc(note)}", style=dashed, color="#b0b0b0", '
                   f'fontcolor="#777777", penwidth=1.0, fontsize=8];')
    return out


# ---------------------------------------------------------------- 그래프 1
def g_hierarchy(d, out):
    classes = {c['id']: c for c in d['classes']}
    lines = [HEADER.format(rankdir='LR', font=FONT, nodesep=0.18, ranksep=1.1,
                           splines='ortho',
                           title='<B>그래프 1 — 클래스 계층 (rdfs:subClassOf)</B><BR/>'
                                 '<FONT POINT-SIZE="9">DITA 매뉴얼 초안 자동화 워크플로우 v3 · '
                                 f'클래스 {len(classes)}개 · 점선 상자 = 재사용 어휘 (P-Plan, PROV-O)</FONT>')]
    used_ext = set()
    # 축별 클러스터
    for axis, (name, pen, fill) in AXES.items():
        members = [c for c in d['classes'] if AXIS_OF.get(c['id']) == axis]
        if not members:
            continue
        lines.append(f'  subgraph cluster_{axis} {{')
        lines.append(f'    label=<<B>{name}</B>>; fontcolor="{pen}"; color="{pen}"; '
                     f'style="rounded"; penwidth=1.2; margin=10;')
        for c in members:
            lines.append('  ' + cls_node(c))
        lines.append('  }')
    for c in d['classes']:
        sup = c['subClassOf']
        if not sup:
            continue
        if sup in EXTERNAL:
            used_ext.add(sup)
        lines.append(f'  {node_id(sup)} -> {node_id(c["id"])} '
                     f'[arrowhead=empty, color="#555555", penwidth=1.1];')
    for e in sorted(used_ext):
        lines.append(ext_node(e))
    lines.append(legend(set(AXES), (
        '빈 화살촉 = rdfs:subClassOf (상위 → 하위)',
        '최상위 14개 클래스는 상위 클래스가 없다',
    )))
    lines.append('}')
    (out / '01-class-hierarchy.dot').write_text('\n'.join(lines), encoding='utf-8')


# ---------------------------------------------------------------- 그래프 2
def g_relationships(d, out):
    classes = {c['id']: c for c in d['classes']}
    obj = [p for p in d['properties']
           if p['kind'] == '객체 속성' and p['domain'] and p['range']]
    obj_gap = [p for p in d['properties']
               if p['kind'] == '객체 속성' and (not p['domain'] or not p['range'])]
    nodes = set()
    for p in obj:
        nodes.add(p['domain']); nodes.add(p['range'])
    for a, b in PROV_BRIDGE:
        nodes.add(a); nodes.add(b)
    for s, t, _, _ in GAP_EDGES:
        nodes.add(s); nodes.add(t)
    nodes |= {'wf:Human', 'wf:LLMAgent', 'wf:Script'}
    lines = [HEADER.format(rankdir='TB', font=FONT, nodesep=0.3, ranksep=1.0,
                           splines='spline',
                           title='<B>그래프 2 — 클래스 간 관계 (객체 속성)</B><BR/>'
                                 f'<FONT POINT-SIZE="9">정의역·치역이 모두 적힌 객체 속성 {len(obj)}개 (실선) · '
                                 f'미기재 {len(obj_gap)}개는 점선으로 표시 · '
                                 '회색 점선 = 재사용 어휘 계층</FONT>')]
    for axis, (name, pen, fill) in AXES.items():
        members = [cid for cid in nodes if AXIS_OF.get(cid) == axis]
        if not members:
            continue
        lines.append(f'  subgraph cluster_r{axis} {{')
        lines.append(f'    label=<<B>{name}</B>>; fontcolor="{pen}"; color="{pen}"; '
                     f'style="rounded"; penwidth=1.2; margin=10;')
        for cid in members:
            c = classes.get(cid, {'id': cid, 'label': cid})
            lines.append('  ' + cls_node(c))
        lines.append('  }')
    for cid in nodes:
        if cid in EXTERNAL:
            lines.append(ext_node(cid))
    lines += prop_edges(obj, show_id=True)
    lines += bridge_and_gap_edges()
    gap_rows = ['<B>정의역·치역 미기재 객체 속성 (점선)</B>'] + \
               [f"{p['id']} — 정의역 {p['domain'] or '(없음)'} / 치역 {p['range'] or '(없음)'}"
                for p in obj_gap]
    lines.append(legend(set(AXES), tuple(gap_rows)))
    lines.append('}')
    (out / '02-class-relationships.dot').write_text('\n'.join(lines), encoding='utf-8')


# ---------------------------------------------------------------- 그래프 3
CORE = {  # 7축의 대표 개념 — 전체 45개 중 자동화 실행에 직접 관여하는 것
    'wf:Workflow','wf:Step','wf:Human','wf:LLMAgent','wf:Script',
    'wf:Artifact','wf:Resource','wf:Template','wf:WorkProduct','wf:Report','wf:FinalDeliverable',
    'wf:SourceMaterial','wf:Transition','wf:Condition','wf:IterationRule','wf:SkipRule',
    'wf:Terminal','wf:Constraint','wf:ExternalTransmission','wf:TransmissionCondition',
    'wf:ManualType','wf:Availability','wf:TopicState',
}


def g_core(d, out):
    classes = {c['id']: c for c in d['classes']}
    obj = [p for p in d['properties']
           if p['kind'] == '객체 속성' and p['domain'] in CORE and p['range'] in CORE]
    lines = [HEADER.format(rankdir='TB', font=FONT, nodesep=0.35, ranksep=0.9,
                           splines='spline',
                           title='<B>그래프 3 — 코어 개념 지도</B><BR/>'
                                 f'<FONT POINT-SIZE="9">자동화 실행에 직접 관여하는 코어 클래스 '
                                 f'{len(CORE)}개와 그 사이의 객체 속성 {len(obj)}개 · '
                                 '하위 분류와 이력 축은 생략</FONT>')]
    for axis, (name, pen, fill) in AXES.items():
        members = [cid for cid in CORE if AXIS_OF.get(cid) == axis]
        if not members:
            continue
        lines.append(f'  subgraph cluster_c{axis} {{')
        lines.append(f'    label=<<B>{name}</B>>; fontcolor="{pen}"; color="{pen}"; '
                     f'style="rounded"; penwidth=1.4; margin=12;')
        for cid in members:
            lines.append('  ' + cls_node(classes[cid]))
        lines.append('  }')
    for e in ('prov:Agent', 'prov:Person', 'prov:SoftwareAgent'):
        lines.append(ext_node(e))
    lines += prop_edges(obj)
    # wf:performedBy — 치역이 prov:Agent라 코어 안에서는 걸러진다. 수행 주체 축 연결을 위해 넣는다.
    pen = AXES['plan'][1]
    lines.append(f'  {node_id("wf:Step")} -> {node_id("prov:Agent")} '
                 f'[label="수행 주체", color="{pen}", fontcolor="{pen}", penwidth=1.2];')
    lines += bridge_and_gap_edges()
    # 계층 (코어 안에서만)
    for cid in CORE:
        sup = classes[cid]['subClassOf']
        if sup in CORE:
            lines.append(f'  {node_id(sup)} -> {node_id(cid)} '
                         f'[arrowhead=empty, color="#555555", style=dashed, penwidth=1.0];')
    c = d['counts']
    lines.append(legend(set(a for a in AXES if any(AXIS_OF.get(x) == a for x in CORE)), (
        '실선 = 객체 속성 · 점선 빈 화살촉 = rdfs:subClassOf',
        '회색 점선 = 재사용 어휘 계층(PROV-O) 또는 정의역·치역 미기재',
        f"전체 규모: 클래스 {c['classes']} · 속성 {c['properties']}"
        f"(객체 {c['object_properties']}/데이터 {c['data_properties']})",
        f"개체: 단계 {c['steps']} · 전이 {c['transitions']} · 외부 전송 {c['transmissions_yes']}",
    )))
    lines.append('}')
    (out / '03-core-concept-map.dot').write_text('\n'.join(lines), encoding='utf-8')


def render(out):
    for dot in sorted(out.glob('*.dot')):
        for fmt in ('png', 'svg'):
            tgt = dot.with_suffix('.' + fmt)
            cmd = ['dot', f'-T{fmt}', str(dot), '-o', str(tgt)]
            if fmt == 'png':
                cmd.insert(1, '-Gdpi=150')
            r = subprocess.run(cmd, capture_output=True, text=True)
            if r.returncode != 0:
                print('FAIL', dot.name, fmt, r.stderr[:400])
            else:
                print('ok  ', tgt.name, f'{tgt.stat().st_size/1024:.0f} KB')


def main():
    src, out = Path(sys.argv[1]), Path(sys.argv[2])
    out.mkdir(parents=True, exist_ok=True)
    d = json.loads(src.read_text(encoding='utf-8'))
    # 축 배정 누락 확인
    missing = [c['id'] for c in d['classes'] if c['id'] not in AXIS_OF]
    if missing:
        print('축 미배정 클래스:', missing)
    g_hierarchy(d, out); g_relationships(d, out); g_core(d, out)
    render(out)


if __name__ == '__main__':
    main()

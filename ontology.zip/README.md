# 워크플로우 온톨로지 — 항목 추출과 시각화 (2026-10-31)

> 입력: `DITA_매뉴얼_초안_자동화_워크플로우_v3.xlsx` (연결 폴더)
> 범위: 업무 자동화 테스트 — 확정 워크플로우 v3(19단계)의 TBox와 코어 개념
> 기준선: 확정 워크플로우 v3, `standard-templates-v3.md`(결정 4~13), 세션요약 2026-10-30(결정 14~18)

## 1. 원본에 대한 주의

**`dita-workflow.ttl`(T03) 원본을 읽지 못했다.** 원본은
`D:\TechStudy\Agent_test\workflow-core\ontology\`에 있는데 이 세션의 연결 폴더
(`C:\Users\bliss\OneDrive\Documents\automation`) 밖이라 접근이 거부되었다.

그래서 **엑셀 v3의 `온톨로지 스키마`·`온톨로지 매핑`·`전이 목록`·`외부 전송`·`검증 규칙·결과`
시트만으로** 추출했다. 엑셀은 온톨로지의 사본 표현이므로, 아래 대조를 한 번 돌려
어긋나지 않았는지 확인해야 이 산출물을 "온톨로지 기준"이라고 말할 수 있다.

```
python3 -I scripts/compare_tbox.py out/tbox-from-xlsx.ttl \
    D:\TechStudy\Agent_test\workflow-core\ontology\dita-workflow.ttl
```

'엑셀에만 있음'·'TTL에만 있음'이 모두 0건이면 일치다. 차이가 나오면 **온톨로지가 원본**이므로
(결정 14) 엑셀 쪽을 고친다.

## 2. 추출 결과

| 항목 | 건수 | 비고 |
|---|---|---|
| 클래스 | 45 | 최상위 14 · 재사용 어휘 상속 6 |
| 속성 | 53 | 객체 25 · 데이터 28 |
| 단계 개체 | 19 | `wf:step01`~`step19` |
| 전이 개체 | 27 | 되돌아감 7 · 반복 횟수 포함 2 |
| 외부 전송 | 15 | 단계 1·2·6·8·13·15·17번 |
| SHACL 규칙 | 8 | R1~R8 (T29) |

클래스를 7개 축으로 묶었다. **이 묶음은 엑셀에 없는 기본값이며 사용자 확인이 필요하다.**

| 축 | 클래스 | 코어 여부 |
|---|---|---|
| 계획·단계 | 11 (`wf:Workflow`, `wf:Step` + 단계 성격 9) | 코어 |
| 수행 주체 | 3 (`wf:Human`, `wf:LLMAgent`, `wf:Script`) | 코어 |
| 자료 | 13 (`wf:Artifact` 아래 `Resource`·`WorkProduct` 계열) | 코어 |
| 흐름 제어 | 6 (`wf:Transition`, `IterationRule`, `SkipRule`, …) | 코어 |
| 통제·보안 | 6 (`wf:Constraint` 계열, `ExternalTransmission`) | 코어 |
| 분류·상태 | 3 (`wf:ManualType`, `TopicState`, `Availability`) | 코어 |
| 이력·근거 | 3 (`wf:Decision`, `ChangeRecord`, `OriginalStep`) | 보조 (실행에 관여하지 않음) |

## 3. 확인된 결함 — 정의역·치역 미기재 17건

엑셀 `온톨로지 스키마` 시트에서 `domain` 또는 `range`가 비어 있는 속성이 **17개**다.
그중 **객체 속성 3개**는 클래스 사이를 잇는 것이라 비어 있으면 그래프가 끊긴다.

| 속성 | 정의역 | 치역 | 그래프에 생기는 문제 |
|---|---|---|---|
| `wf:toStep` | `wf:Transition` | **(없음)** | `wf:Terminal`이 고립 — 종료 지점에 닿는 간선이 없다 |
| `wf:hasConstraint` | **(없음)** | `wf:Constraint` | `wf:Constraint` 계열 전체가 고립 |
| `wf:justifiedBy` | **(없음)** | `wf:Decision` | `wf:Decision`이 고립 |

`wf:toStep`의 치역이 비어 있는 것은 **의도적일 수 있다**: `wf:t19_end`의 도착이 `종료`라서
치역이 `wf:Step ∪ wf:Terminal`이 되고, 단일 클래스로 적을 수 없다. 이 경우 `owl:unionOf`로
적는 것이 맞다. 나머지 2개는 단순 누락으로 보인다. **셋 다 추정이므로 TTL 대조가 필요하다.**

그래프에서는 이 3건을 **회색 점선**으로 그리고 `(치역 미기재, 추정: …)`이라고 적었다.
고립된 채 두지 않고 결함을 드러내기 위해서다.

데이터 속성 14건(`wf:reason`, `wf:scope`, `wf:change` 등)의 미기재는 그래프에 영향이 없다.
전체 목록은 `out/properties.csv`에서 빈 칸으로 확인할 수 있다.

## 4. 수행 주체 축이 이어지는 경로

`wf:performedBy`의 치역은 `prov:Agent`인데, 엑셀에는 `wf:Human`·`wf:LLMAgent`·`wf:Script`가
`prov:Person`·`prov:SoftwareAgent`를 상속한다고만 적혀 있다. 둘을 잇는
`prov:Person ⊑ prov:Agent`·`prov:SoftwareAgent ⊑ prov:Agent`는 **PROV-O 규격에 있고 엑셀에는 없다.**

이 두 줄이 없으면 수행 주체 축이 단계와 끊어져 보이므로 그래프에 회색 점선으로 넣었다.
근거: W3C PROV-O Recommendation (2013-04-30), `prov:Person`·`prov:SoftwareAgent`의 상위 클래스는
`prov:Agent` — <https://www.w3.org/TR/2013/REC-prov-o-20130430/>

## 5. 그래프 3종

| 파일 | 내용 | 쓰임 |
|---|---|---|
| `graphs/01-class-hierarchy` | 클래스 45개의 `rdfs:subClassOf` 계층, 축별 묶음 | 분류 체계 검토 |
| `graphs/02-class-relationships` | 객체 속성 25개를 간선으로 (미기재 3건 점선) | 연결 끊김 검출 |
| `graphs/03-core-concept-map` | 코어 23개와 그 사이 관계만 | 설명·리뷰용 |

각각 `.dot`(원본) · `.png`(150 dpi) · `.svg`(확대용)로 있다. 글꼴은 Noto Sans CJK KR.
`.dot`을 고쳐 다시 그리려면 `dot -Tpng -Gdpi=150 <파일>.dot -o <파일>.png`.

## 6. 검증 — 확인한 것

| 검사 | 결과 |
|---|---|
| V1 시트 직접 집계와 추출 건수 일치 (클래스 45 · 속성 53) | 통과 |
| V2 클래스·속성 ID 중복 없음 | 통과 |
| V3 TTL 왕복 (쓰고 다시 읽어 같은 집합) | 통과 |
| V4 `rdfs:subClassOf` 순환 없음 | 통과 |
| V5 전이 27개의 단계 번호가 1~19 범위 (`wf:t19_end`만 도착이 `종료`) | 통과 |
| V6 2~19번 모두 전이로 도달 가능 | 통과 |
| V7 외부 전송 15건 — 세션요약 2026-10-30 기재값과 일치 | 통과 |

## 7. 검증 — 확인하지 못한 것

- **원본 `dita-workflow.ttl`과의 일치** (파일 접근 불가). 5절의 `compare_tbox.py`로 확인해야 한다.
  세션요약의 "트리플 약 1,529개"와 이 TBox 321개는 비교 대상이 아니다 — 원본은 개체(ABox)를 포함한다.
- **7개 축 묶음과 코어 23개 선별** — 엑셀에 근거가 없는 기본값이다.
- **단계 성격 클래스**(`wf:ApprovalStep` 등) 배정 — 엑셀 `워크플로우` 시트에 단계별 성격 열이 없어
  단계 이름에서 규칙으로 유도했다. `individuals-steps.csv`의 `stepClass` 열이 그 결과이며,
  TTL 원본의 `rdf:type`과 대조해야 한다.
- `wf:toStep`·`wf:hasConstraint`·`wf:justifiedBy`의 실제 정의역·치역.

## 8. 파일

```
ontology/
  README.md
  scripts/extract_ontology.py    엑셀 → ontology-core.json + CSV
  scripts/gen_graphs.py          JSON → DOT → PNG/SVG
  scripts/emit_tbox.py           JSON → Turtle (TBox만)
  scripts/compare_tbox.py        TBox ↔ 원본 dita-workflow.ttl 대조
  out/ontology-core.json         클래스·속성·개체 (schema_version 1.0)
  out/classes.csv  properties.csv  individuals-steps.csv
  out/tbox-from-xlsx.ttl         트리플 321개
  graphs/01~03  (.dot/.png/.svg)
```

실행 순서:

```
python3 -I scripts/extract_ontology.py <v3.xlsx> out
python3 -I scripts/emit_tbox.py out/ontology-core.json out/tbox-from-xlsx.ttl
python3 -I scripts/gen_graphs.py out/ontology-core.json graphs
```

필요한 것: Python 3.10+, `openpyxl`, `rdflib`, graphviz(`dot`), Noto Sans CJK KR 글꼴.
